package pe.edu.pucp.model.ventas;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.model.enums.EstadoComprobante;
import pe.edu.pucp.model.enums.Moneda;
import pe.edu.pucp.model.enums.TipoComprobante;

/**
 * Comprobante electronico asociado a una venta (RF008).
 */
public class Comprobante {
    private int id;
    private Venta venta;
    private TipoComprobante tipo;
    private String serie;
    private String numero;
    private LocalDate fechaEmision;
    private Moneda moneda;
    private double subTotal;
    private double igv;
    private double total;
    private EstadoComprobante estado;
    private Comprobante comprobanteRelacionado;
    private String medioEnvio;
    private LocalDateTime fechaEnvio;
    private LocalDateTime fechaRegistro;
    private String motivo;
    private List<DetalleNotaCredito> detalles;

    public Comprobante() {
        this.detalles = new ArrayList<>();
    }

    public Comprobante(int id, Venta venta, TipoComprobante tipo,
                       String serie, String numero, LocalDate fechaEmision,
                       Moneda moneda, double subTotal, double igv, double total,
                       EstadoComprobante estado, Comprobante comprobanteRelacionado,
                       String medioEnvio, LocalDateTime fechaEnvio,
                       LocalDateTime fechaRegistro) {
        this();
        this.id = id;
        this.venta = venta;
        this.tipo = tipo;
        this.serie = serie;
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.moneda = moneda;
        this.subTotal = subTotal;
        this.igv = igv;
        this.total = total;
        this.estado = estado;
        this.comprobanteRelacionado = comprobanteRelacionado;
        this.medioEnvio = medioEnvio;
        this.fechaEnvio = fechaEnvio;
        this.fechaRegistro = fechaRegistro;
    }

    public Comprobante(int id, Venta venta, TipoComprobante tipo,
                       String serie, String numero, LocalDate fechaEmision,
                       Moneda moneda, double subTotal, double igv, double total,
                       EstadoComprobante estado, Comprobante comprobanteRelacionado,
                       String medioEnvio, LocalDateTime fechaEnvio,
                       LocalDateTime fechaRegistro, String motivo,
                       List<DetalleNotaCredito> detalles) {
        this.id = id;
        this.venta = venta;
        this.tipo = tipo;
        this.serie = serie;
        this.numero = numero;
        this.fechaEmision = fechaEmision;
        this.moneda = moneda;
        this.subTotal = subTotal;
        this.igv = igv;
        this.total = total;
        this.estado = estado;
        this.comprobanteRelacionado = comprobanteRelacionado;
        this.medioEnvio = medioEnvio;
        this.fechaEnvio = fechaEnvio;
        this.fechaRegistro = fechaRegistro;
        this.motivo = motivo;
        this.detalles = detalles != null ? detalles : new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public TipoComprobante getTipo() {
        return tipo;
    }

    public void setTipo(TipoComprobante tipo) {
        this.tipo = tipo;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public LocalDate getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(LocalDate fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public Moneda getMoneda() {
        return moneda;
    }

    public void setMoneda(Moneda moneda) {
        this.moneda = moneda;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    public double getIgv() {
        return igv;
    }

    public void setIgv(double igv) {
        this.igv = igv;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public EstadoComprobante getEstado() {
        return estado;
    }

    public void setEstado(EstadoComprobante estado) {
        this.estado = estado;
    }

    public Comprobante getComprobanteRelacionado() {
        return comprobanteRelacionado;
    }

    public void setComprobanteRelacionado(Comprobante comprobanteRelacionado) {
        this.comprobanteRelacionado = comprobanteRelacionado;
    }

    public String getMedioEnvio() {
        return medioEnvio;
    }

    public void setMedioEnvio(String medioEnvio) {
        this.medioEnvio = medioEnvio;
    }

    public LocalDateTime getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDateTime fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public List<DetalleNotaCredito> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleNotaCredito> detalles) {
        this.detalles = detalles;
    }
}
