param(
    [string]$Proyecto = "."
)

$ErrorActionPreference = "Stop"

$raiz = (Resolve-Path $Proyecto).Path
$parche = Join-Path $PSScriptRoot "parche\sigmeta"

$destinoSigmeta = Join-Path $raiz "sigmeta"
if (-not (Test-Path $destinoSigmeta)) {
    Write-Host "No se encontro la carpeta 'sigmeta' en: $raiz" -ForegroundColor Red
    Write-Host "Ejecuta este script desde la raiz del repositorio SIGMETA-P3, o usa:" -ForegroundColor Yellow
    Write-Host ".\APLICAR_CAMBIOS.ps1 -Proyecto C:\ruta\SIGMETA-P3" -ForegroundColor Yellow
    exit 1
}

Write-Host "Aplicando archivos nuevos/modificados..." -ForegroundColor Cyan
Copy-Item -Path (Join-Path $parche "*") -Destination $destinoSigmeta -Recurse -Force

$eliminar = @(
    "sigmeta\src\main\java\pe\edu\pucp\model\almacen\OrdenProduccionDto.java",
    "sigmeta\src\main\java\pe\edu\pucp\model\almacen\DetalleOrdenProduccionDto.java",
    "sigmeta\src\main\java\pe\edu\pucp\model\producto\ComponenteProductoDto.java",
    "sigmeta\src\main\java\pe\edu\pucp\model\enums\EstadoOrdenProduccion.java",
    "sigmeta\src\main\java\pe\edu\pucp\model\enums\TipoProducto.java"
)

Write-Host "Eliminando archivos de produccion fuera del alcance..." -ForegroundColor Cyan
foreach ($rel in $eliminar) {
    $p = Join-Path $raiz $rel
    if (Test-Path $p) {
        Remove-Item $p -Force
        Write-Host "  Eliminado: $rel"
    } else {
        Write-Host "  No existia: $rel"
    }
}

Write-Host ""
Write-Host "Cambios aplicados sobre TU proyecto completo." -ForegroundColor Green
Write-Host "Siguiente paso recomendado:" -ForegroundColor Yellow
Write-Host "  cd sigmeta"
Write-Host "  mvn clean compile"
Write-Host ""
Write-Host "Si compila, ya puedes hacer git add, commit y push."
