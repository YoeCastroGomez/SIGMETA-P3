SIGMETA - ACTUALIZACION AUTOMATICA DEL MODELO

Este paquete NO reemplaza tu repositorio completo.
Se aplica SOBRE tu repositorio actual y, al terminar, TU MISMO PROYECTO queda completo
con todo lo que ya tenia + las modificaciones del modelo.

USO
1. Descomprime este ZIP.
2. Copia la carpeta descomprimida dentro de la raiz de SIGMETA-P3, o abre PowerShell
   en la carpeta descomprimida.
3. Ejecuta:

   powershell -ExecutionPolicy Bypass -File .\APLICAR_CAMBIOS.ps1 -Proyecto "C:\ruta\SIGMETA-P3"

   Si colocaste el aplicador directamente en la raiz del repo:
   powershell -ExecutionPolicy Bypass -File .\APLICAR_CAMBIOS.ps1

4. El script:
   - conserva todos tus archivos existentes;
   - agrega las clases nuevas;
   - reemplaza solo las clases que necesitan cambios;
   - elimina las clases de produccion que ya no corresponden al informe final.

ARCHIVOS QUE ELIMINA
- OrdenProduccionDto.java
- DetalleOrdenProduccionDto.java
- ComponenteProductoDto.java
- EstadoOrdenProduccion.java
- TipoProducto.java

DESPUES
cd sigmeta
mvn clean compile

Luego:
git add .
git commit -m "Alinear modelo Java con requerimientos finales"
git push

NOTA
No pude generar una copia binaria exacta del ZIP completo original porque el archivo
adjunto no esta montado en el entorno de ejecucion. Este aplicador evita reconstruir
o perder tus archivos: modifica directamente TU copia completa del proyecto.
